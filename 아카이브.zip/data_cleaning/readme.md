1. data_load: original data 정리
2. local_data: 지역으로 범위 좁힘
