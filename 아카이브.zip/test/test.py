import os, sys

# print(os.getcwd())


original_filename = 'original_data.csv'

# # current_dir = os.path.dirname(__file__)
# # print(current_dir)

# # data_dir = os.path.join(current_dir, '..', 'data')
# # print(data_dir)

# # original_data_path = os.path.join(data_dir, original_filename)
# # print(original_data_path)

# DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'data')

# # 데이터 파일 경로
# data_file_path = os.path.join(DATA_DIR, original_filename)

# sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# print(os.path.abspath(__file__)) # 절대경로 반환
abs_root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


print(data_path)
# print(a)
# print(type(a))

# new_path = os.path.join(abs_root_path, 'sort_dist')

# data path
abs_root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
data_path = os.path.join(abs_root_path, 'data')

# 상위 모듈 임포트
abs_root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(abs_root_path)
from data_cleaning import sort_dist
print("some_module 경로:", sort_dist.__file__)

# 1. cleaning_script

# data path
abs_root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
data_dir = os.path.join(abs_root_path, 'data/')

original_filename = 'original_data.csv'
original_data_path = os.path.join(data_dir, original_filename)

# -------------------------------------------------------------------------



# ----------------------------------------------------------------------
## INPUTS ==============================================================
## =====================================================================


## 1. 공휴일 가져오는 데이터포털 api -----------------------------------------------------------------------
## 2. 영업정보 확인 -------------------------------------------------------------------------------------
## 3. 적용 --------------------------------------------------------------------------------------------



